package pknu.it.pknuapp.Activities.ui.signout;


import android.os.Bundle;

import androidx.fragment.app.Fragment;


public class SignoutFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }



}